<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php';
session_start();

if(isset($_GET['logout'])){session_destroy();header('Location: index.php');exit;}
if(empty($_SESSION['admin'])){
    if($_SERVER['REQUEST_METHOD']==='POST' && hash_equals(ADMIN_USER,$_POST['user']??'') && hash_equals(ADMIN_PASS,$_POST['pass']??'')){
        $_SESSION['admin']=true; header('Location:index.php'); exit;
    }
    ?>
    <!doctype html><html><body style="font-family:Arial;max-width:400px;margin:60px auto">
    <h2>Study Administration</h2><form method="post">
    <input name="user" placeholder="Username" required><br><br>
    <input name="pass" type="password" placeholder="Password" required><br><br>
    <button>Login</button></form></body></html>
    <?php exit;
}
$pdo=db(); $c=config();
$total=(int)$pdo->query("SELECT COUNT(*) FROM attempts")->fetchColumn();
$participants=(int)$pdo->query("SELECT COUNT(*) FROM participants")->fetchColumn();
$complete=(int)$pdo->query("SELECT COUNT(*) FROM participants WHERE completed_at IS NOT NULL")->fetchColumn();

if(isset($_GET['export'])){
    header('Content-Type:text/csv; charset=utf-8');
    header('Content-Disposition:attachment; filename="dsu_keystroke_features.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,['Sample_ID','User_ID','Attempt_Number','Median_Hold_Time','Median_Flight_Time','Std_Hold_Time','Std_Flight_Time','Avg_Hold_Time','Avg_Flight_Time','Total_Entry_Time']);
    $q=$pdo->query("SELECT a.id,p.user_code,a.attempt_number,a.median_hold_time,a.median_flight_time,a.std_hold_time,a.std_flight_time,a.avg_hold_time,a.avg_flight_time,a.total_entry_time
                    FROM attempts a JOIN participants p ON p.id=a.participant_id ORDER BY p.id,a.attempt_number");
    while($r=$q->fetch()) fputcsv($out,$r);
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>DSU Study Admin</title>
<style>body{font-family:Arial;margin:40px;background:#f5f7fa}.card{background:#fff;padding:20px;margin:10px 0;border-radius:10px}a,button{padding:10px;text-decoration:none}</style></head>
<body><h1>DSU Keystroke Study</h1>
<div class="card"><b>Participants:</b> <?=$participants?> &nbsp; <b>Completed:</b> <?=$complete?> &nbsp; <b>Attempts:</b> <?=$total?></div>
<div class="card"><a href="?export=1">Export feature CSV</a> &nbsp; <a href="?logout=1">Logout</a></div>
<div class="card"><h3>Study configuration</h3><p>Password: <b><?=htmlspecialchars($c['password_text'])?></b></p><p>Attempts per participant: <b><?=$c['target_attempts']?></b></p></div>
</body></html>
