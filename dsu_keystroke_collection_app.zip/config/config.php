<?php
declare(strict_types=1);

const DB_HOST = '127.0.0.1';
const DB_NAME = 'keystroke_study';
const DB_USER = 'keystroke_app';
const DB_PASS = 'CHANGE_THIS_STRONG_PASSWORD';

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'CHANGE_THIS_ADMIN_PASSWORD';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
    }
    return $pdo;
}

function config(): array {
    return db()->query("SELECT * FROM study_config WHERE id=1")->fetch();
}

function json_response(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
