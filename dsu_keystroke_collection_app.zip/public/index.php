<?php
require_once __DIR__.'/../config/config.php';
$c = config();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($c['study_name'])?></title>
<style>
body{font-family:Arial,sans-serif;background:#f5f7fa;margin:0;color:#202124}
main{max-width:760px;margin:40px auto;background:white;padding:30px;border-radius:12px;box-shadow:0 3px 16px #0001}
h1{margin-top:0}.notice{background:#eef4ff;padding:15px;border-radius:8px}
input,button{font-size:18px;padding:12px;margin-top:8px}button{cursor:pointer}
.hidden{display:none}.password{font:700 30px monospace;letter-spacing:4px;background:#f1f3f4;padding:18px;text-align:center}
.progress{height:12px;background:#ddd;border-radius:10px;overflow:hidden}.bar{height:100%;width:0;background:#1a73e8}
#error{color:#b00020}.ok{color:#087f23}
</style>
</head>
<body>
<main>
<h1><?=htmlspecialchars($c['study_name'])?></h1>

<section id="registration">
<h2>Participant registration</h2>
<div class="notice">
<p>This study records <b>keyboard timing characteristics</b>, not your personal password.</p>
<p>Use the study password shown below. Do not enter a personal or account password.</p>
<p>Participation is voluntary. Your research ID is anonymous.</p>
</div>
<label><input type="checkbox" id="consent"> I consent to participate in this keystroke-dynamics study.</label>
<br>
<button onclick="startRegistration()">Continue</button>
<p id="error"></p>
</section>

<section id="test" class="hidden">
<h2>Typing test</h2>
<p>Your anonymous participant ID:</p>
<p><b id="userCode"></b></p>
<p>Type the following password exactly as displayed:</p>
<div class="password" id="studyPassword"></div>
<p>Attempt <b id="attemptNo"></b> of <b id="totalAttempts"></b></p>
<div class="progress"><div class="bar" id="bar"></div></div>
<p>Click the input, then type the password naturally. Do not copy/paste.</p>
<input id="typingBox" autocomplete="off" autocapitalize="off" spellcheck="false" />
<p id="status"></p>
</section>

<section id="done" class="hidden">
<h2>Thank you</h2>
<p>Your 50 typing samples have been recorded successfully.</p>
<p>Your anonymous participant ID is <b id="doneCode"></b>.</p>
</section>
</main>

<script>
let participantId=null, userCode=null, attempt=0, target=50;
let events=[], startedAt=null, active=false;

async function startRegistration(){
  if(!document.getElementById('consent').checked){
    document.getElementById('error').textContent='Please provide consent to continue.';
    return;
  }
  const r=await fetch('api.php?action=register',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({consent:true})});
  const j=await r.json();
  if(!j.ok){document.getElementById('error').textContent=j.error||'Registration failed.';return;}
  participantId=j.participant_id; userCode=j.user_code; attempt=j.next_attempt; target=j.target_attempts;
  document.getElementById('userCode').textContent=userCode;
  document.getElementById('studyPassword').textContent=j.password;
  document.getElementById('totalAttempts').textContent=target;
  document.getElementById('registration').classList.add('hidden');
  document.getElementById('test').classList.remove('hidden');
  prepareAttempt();
}

function prepareAttempt(){
  events=[]; startedAt=null; active=false;
  const box=document.getElementById('typingBox');
  box.value=''; box.disabled=false; box.focus();
  document.getElementById('attemptNo').textContent=attempt;
  document.getElementById('bar').style.width=((attempt-1)/target*100)+'%';
  document.getElementById('status').textContent='Type the password.';
}

const box=document.getElementById('typingBox');
box.addEventListener('keydown', e=>{
  if(e.repeat || !active && events.length>0) return;
  if(startedAt===null) startedAt=performance.now();
  active=true;
  events.push({key:e.key,code:e.code,press:performance.now()});
});
box.addEventListener('keyup', e=>{
  if(!active) return;
  const t=performance.now();
  for(let i=events.length-1;i>=0;i--){
    if(events[i].key===e.key && events[i].release===undefined){
      events[i].release=t; break;
    }
  }
  const expected=document.getElementById('studyPassword').textContent;
  if(box.value===expected && events.length===expected.length && events.every(x=>x.release!==undefined)){
    active=false; box.disabled=true; submitAttempt();
  } else if(box.value.length>=expected.length && box.value!==expected){
    document.getElementById('status').textContent='Password incorrect. Please clear the box and try again.';
  }
});

async function submitAttempt(){
  const r=await fetch('api.php?action=attempt',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({participant_id:participantId,attempt_number:attempt,events:events})});
  const j=await r.json();
  if(!j.ok){document.getElementById('status').textContent=j.error||'Could not save attempt.';box.disabled=false;return;}
  document.getElementById('status').innerHTML='<span class="ok">Saved.</span>';
  if(attempt>=target){
    document.getElementById('test').classList.add('hidden');
    document.getElementById('done').classList.remove('hidden');
    document.getElementById('doneCode').textContent=userCode;
  } else {
    attempt++; setTimeout(prepareAttempt,700);
  }
}
</script>
</body>
</html>
