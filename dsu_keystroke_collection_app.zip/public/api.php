<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php';

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?: [];
$c = config();

if ($action === 'register') {
    if (($input['consent'] ?? false) !== true) json_response(['ok'=>false,'error'=>'Consent is required.'],400);
    $pdo=db();
    $pdo->beginTransaction();
    try {
        $next=(int)$pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM participants")->fetchColumn();
        $code='DSU-'.str_pad((string)$next,4,'0',STR_PAD_LEFT);
        $st=$pdo->prepare("INSERT INTO participants(user_code,consented) VALUES(?,1)");
        $st->execute([$code]);
        $id=(int)$pdo->lastInsertId();
        $pdo->commit();
        json_response(['ok'=>true,'participant_id'=>$id,'user_code'=>$code,'password'=>$c['password_text'],
                       'target_attempts'=>(int)$c['target_attempts'],'next_attempt'=>1]);
    } catch(Throwable $e) {
        $pdo->rollBack(); json_response(['ok'=>false,'error'=>'Registration failed.'],500);
    }
}

if ($action === 'attempt') {
    $pid=(int)($input['participant_id'] ?? 0);
    $num=(int)($input['attempt_number'] ?? 0);
    $events=$input['events'] ?? [];
    if($pid<1 || $num<1 || $num>(int)$c['target_attempts']) json_response(['ok'=>false,'error'=>'Invalid attempt.'],400);

    $expected=$c['password_text'];
    if(count($events)!==mb_strlen($expected)) json_response(['ok'=>false,'error'=>'Incorrect event count.'],400);

    $chars=mb_str_split($expected);
    $hold=[]; $flight=[]; $clean=[];
    foreach($events as $i=>$ev){
        if(!isset($ev['key'],$ev['press'],$ev['release'])) json_response(['ok'=>false,'error'=>'Invalid keyboard event.'],400);
        if((string)$ev['key']!==$chars[$i]) json_response(['ok'=>false,'error'=>'Password mismatch.'],400);
        $p=(float)$ev['press']; $r=(float)$ev['release'];
        if($r<$p) json_response(['ok'=>false,'error'=>'Invalid timestamps.'],400);
        $h=$r-$p; $hold[]=$h;
        $clean[]=['key'=>$ev['key'],'code'=>$ev['code']??null,'press'=>$p,'release'=>$r,'hold'=>$h];
    }
    for($i=0;$i<count($clean)-1;$i++) $flight[]=$clean[$i+1]['press']-$clean[$i]['release'];

    $avg=function($a){return array_sum($a)/count($a);};
    $median=function($a){sort($a,SORT_NUMERIC);$n=count($a);return $n%2?$a[intdiv($n,2)]:($a[$n/2-1]+$a[$n/2])/2;};
    $std=function($a)use($avg){$m=$avg($a);return sqrt(array_sum(array_map(fn($x)=>($x-$m)**2,$a))/count($a));};
    $total=end($clean)['release']-$clean[0]['press'];

    $pdo=db();
    try{
        $pdo->beginTransaction();
        $q=$pdo->prepare("SELECT id FROM participants WHERE id=? AND consented=1");
        $q->execute([$pid]);
        if(!$q->fetch()){throw new Exception('Participant not found');}
        $st=$pdo->prepare("INSERT INTO attempts
          (participant_id,attempt_number,median_hold_time,median_flight_time,std_hold_time,std_flight_time,avg_hold_time,avg_flight_time,total_entry_time)
          VALUES(?,?,?,?,?,?,?,?,?)");
        $st->execute([$pid,$num,$median($hold),$median($flight),$std($hold),$std($flight),$avg($hold),$avg($flight),$total]);
        $aid=(int)$pdo->lastInsertId();
        $evst=$pdo->prepare("INSERT INTO key_events
          (attempt_id,key_index,key_name,key_code,press_time_ms,release_time_ms,hold_time_ms,flight_time_ms)
          VALUES(?,?,?,?,?,?,?,?)");
        for($i=0;$i<count($clean);$i++){
            $f=$i<count($flight)?$flight[$i]:null;
            $evst->execute([$aid,$i+1,$clean[$i]['key'],$clean[$i]['code'],
                round($clean[$i]['press'],2),round($clean[$i]['release'],2),round($clean[$i]['hold'],2),
                $f===null?null:round($f,2)]);
        }
        if($num===(int)$c['target_attempts'])
            $pdo->prepare("UPDATE participants SET completed_at=NOW() WHERE id=?")->execute([$pid]);
        $pdo->commit();
        json_response(['ok'=>true]);
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        if(str_contains($e->getMessage(),'Duplicate')) json_response(['ok'=>false,'error'=>'This attempt is already saved.'],409);
        json_response(['ok'=>false,'error'=>'Could not save the attempt.'],500);
    }
}

json_response(['ok'=>false,'error'=>'Unknown action.'],404);
