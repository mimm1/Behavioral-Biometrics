# DSU Keystroke Dynamics Data Collection Application

## Purpose
Collect keyboard timing data from 50 students, with 50 repetitions per participant.

The application stores:
1. Raw key events (press/release timestamps, dwell and flight times)
2. Seven derived features per password attempt

## Privacy
- Do NOT collect students' real passwords.
- Use only the study password configured in `study_config`.
- Use anonymous participant codes such as DSU-0001.
- Keep any student identity/code mapping outside the biometric dataset.
- Obtain institutional/ethics approval and informed consent before collection.

## Deployment

Recommended environment:
- Ubuntu
- Apache
- PHP 7.4+ (PHP 8.x preferred)
- MySQL/MariaDB
- HTTPS

### 1. Database
Create a database account, then run `sql/schema.sql`.

Example:
```sql
CREATE USER 'keystroke_app'@'localhost' IDENTIFIED BY 'YOUR_STRONG_DB_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON keystroke_study.* TO 'keystroke_app'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Configure
Edit `config/config.php`:
- DB_USER
- DB_PASS
- ADMIN_USER
- ADMIN_PASS

### 3. Web root
Point Apache document root to `public/`.

The admin directory should preferably be protected by HTTPS and an additional server-level restriction.

### 4. URLs
Participant page:
`https://YOUR-DOMAIN/`

Admin:
`https://YOUR-DOMAIN/admin/`

## Dataset
For 50 students × 50 attempts:
- 2,500 attempt-level rows
- 50 participant classes
- 7 derived timing features

`Attempt_Number` is retained for temporal drift analysis and should generally NOT be supplied to a classifier as a biometric feature.

## Drift
The application records real chronological attempts. It does not fabricate drift. Any gradual drift observed in the students' typing should arise from the actual repeated measurements.

For a controlled drift experiment, analyze temporal blocks such as:
1–10, 11–20, 21–30, 31–40, 41–50.

## Security
This is a research prototype. Before production deployment:
- Use HTTPS.
- Change all default passwords.
- Add CSRF protection to admin forms.
- Add rate limiting.
- Restrict admin access by VPN/IP if possible.
- Use a separate DB account with least privilege.
- Back up the database securely.
- Avoid storing names, CNICs, email addresses, or actual passwords in the biometric dataset.
