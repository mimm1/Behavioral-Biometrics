CREATE DATABASE IF NOT EXISTS keystroke_study
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE keystroke_study;

CREATE TABLE study_config (
  id TINYINT UNSIGNED PRIMARY KEY,
  study_name VARCHAR(200) NOT NULL,
  password_text VARCHAR(100) NOT NULL,
  target_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 50,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO study_config (id, study_name, password_text, target_attempts)
VALUES (1, 'DSU Keystroke Dynamics Study', 'DSU@2026AI', 50);

CREATE TABLE participants (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_code VARCHAR(20) NOT NULL UNIQUE,
  consented TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL
);

CREATE TABLE attempts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  participant_id INT UNSIGNED NOT NULL,
  attempt_number SMALLINT UNSIGNED NOT NULL,
  median_hold_time DECIMAL(10,2) NULL,
  median_flight_time DECIMAL(10,2) NULL,
  std_hold_time DECIMAL(10,2) NULL,
  std_flight_time DECIMAL(10,2) NULL,
  avg_hold_time DECIMAL(10,2) NULL,
  avg_flight_time DECIMAL(10,2) NULL,
  total_entry_time DECIMAL(10,2) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_participant_attempt (participant_id, attempt_number),
  CONSTRAINT fk_attempt_participant
    FOREIGN KEY (participant_id) REFERENCES participants(id)
    ON DELETE CASCADE
);

CREATE TABLE key_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  attempt_id BIGINT UNSIGNED NOT NULL,
  key_index SMALLINT UNSIGNED NOT NULL,
  key_name VARCHAR(20) NOT NULL,
  key_code VARCHAR(40) NULL,
  press_time_ms BIGINT UNSIGNED NOT NULL,
  release_time_ms BIGINT UNSIGNED NOT NULL,
  hold_time_ms DECIMAL(10,2) NOT NULL,
  flight_time_ms DECIMAL(10,2) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_attempt (attempt_id),
  CONSTRAINT fk_event_attempt
    FOREIGN KEY (attempt_id) REFERENCES attempts(id)
    ON DELETE CASCADE
);
